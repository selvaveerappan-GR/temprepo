#!/usr/bin/env python3
"""Generate the Self Service Patching logo (Intune/Company Portal PNG + shortcut .ico).

Pure Python standard library - no Pillow, ImageMagick or librsvg needed, so the artwork is
reproducible on any machine with python3 and can be tweaked and regenerated rather than
being an opaque binary. Shapes are analytic inside-tests sampled with 4x4 supersampling,
which is what gives clean anti-aliased edges at every size.

    python3 New-AppLogo.py                      # writes both, to the default locations
    python3 New-AppLogo.py --png-size 512       # larger Company Portal image
    python3 New-AppLogo.py --preview            # upscaled sheet for judging small sizes

Design: a full-bleed rounded tile in the app's accent blue with transparent corners, so it
composites correctly on both the light and dark Company Portal themes. On it, a solid
shield in the app's foreground white with a download arrow knocked out of it - "patching"
read as secure updates. Colours are the design-system tokens recorded in CLAUDE.md:
Accent #4C8DFF for the tile (with a +/-8% vertical gradient for a little depth) and
Fg #EDEDF5 for the mark.

Two geometries, not one. The detailed mark turns to mush below about 24px - the arrow's
base bar is the first thing to merge into the stem - so small sizes get a simplified mark:
no base bar, a bolder arrow, and a shield enlarged to use more of the available pixels.
Both share the same silhouette, so the icon still looks like itself at 16px.
"""

import argparse
import binascii
import math
import struct
import zlib

# Design-system tokens (see the GUI design system section of CLAUDE.md).
ACCENT = (0x4C, 0x8D, 0xFF)
FG = (0xED, 0xED, 0xF5)

GRADIENT_SPREAD = 0.08   # +/- this fraction of the accent, top to bottom
TILE_RADIUS = 0.20       # corner radius as a fraction of the tile size
SUPERSAMPLE = 4          # samples per axis per pixel

SIMPLIFY_AT_OR_BELOW = 24   # px; below this the detailed mark stops being legible

# Shield lengths are fractions of the tile; arrow coordinates are shield-local, with x
# measured from the shield's centre line and y from 0 (top of shield) to 1 (its point),
# both in units of the shield's height.
DETAILED = {
    'shield_height': 0.60,
    'shield_half_width': 0.30,
    'shield_centre_y': 0.47,    # a shade above centre: optically centred, not mathematically
    'shoulder': 0.40,           # fraction of the shield that is straight-sided
    'top_radius': 0.14,         # top corner rounding, as a fraction of the half width
    'stem_top': 0.20,
    'stem_bottom': 0.47,
    'stem_half_width': 0.062,
    'head_top': 0.42,
    'head_tip': 0.63,
    'head_half_width': 0.185,
    'bar': True,
    'bar_top': 0.655,
    'bar_bottom': 0.725,
    'bar_half_width': 0.165,
    'bar_radius': 0.030,
}

SIMPLIFIED = dict(DETAILED, **{
    'shield_height': 0.74,      # fill more of the tile when pixels are scarce
    'shield_half_width': 0.37,
    'shield_centre_y': 0.50,
    'stem_top': 0.17,
    'stem_bottom': 0.46,
    'stem_half_width': 0.095,   # bolder, so it survives being a couple of pixels wide
    'head_top': 0.40,
    'head_tip': 0.70,
    'head_half_width': 0.255,
    'bar': False,               # first thing to merge into the stem; drop it
})

TAPER_POWER = 2.0   # see shield_half_width


def geometry_for(size):
    return SIMPLIFIED if size <= SIMPLIFY_AT_OR_BELOW else DETAILED


def lerp(a, b, t):
    return a + (b - a) * t


def tile_colour(v):
    """Vertical gradient centred on the accent colour. v is 0 at the top, 1 at the bottom."""
    factor = lerp(1.0 + GRADIENT_SPREAD, 1.0 - GRADIENT_SPREAD, v)
    return tuple(min(255, max(0, int(round(c * factor)))) for c in ACCENT)


def in_rounded_rect(x, y, w, h, r):
    """x, y in [0, w] x [0, h]; r is the corner radius."""
    if x < 0 or y < 0 or x > w or y > h:
        return False
    # Clamp to the centre of the nearest corner circle, then test the distance.
    cx = min(max(x, r), w - r)
    cy = min(max(y, r), h - r)
    dx = x - cx
    dy = y - cy
    if dx == 0 or dy == 0:
        return True          # inside the straight-edged cross of the shape
    return dx * dx + dy * dy <= r * r


def shield_half_width(y, g):
    """Half width of the shield at depth y (0 = top, 1 = point), in shield-height units."""
    if y < 0.0 or y > 1.0:
        return -1.0
    hw = g['shield_half_width']
    if y <= g['shoulder']:
        rt = g['top_radius'] * hw
        if y < rt:
            # Round the top corners: ease the half width in over the first rt of depth.
            return hw - rt + math.sqrt(max(0.0, rt * rt - (rt - y) ** 2))
        return hw
    # Below the shoulder, taper to a point at y = 1. Note 1 - u**2 and NOT the quarter
    # ellipse sqrt(1 - u**2): the latter is still 77% of full width at 80% depth, which
    # reads as a capsule or thermometer bulb rather than a shield. This narrows gently at
    # first and steeply at the end, which is the heraldic shape.
    u = (y - g['shoulder']) / (1.0 - g['shoulder'])
    return hw * max(0.0, 1.0 - u ** TAPER_POWER)


def in_shield(x, y, g):
    hw = shield_half_width(y, g)
    return hw >= 0.0 and abs(x) <= hw


def in_arrow(x, y, g):
    ax = abs(x)
    # Stem.
    if g['stem_top'] <= y <= g['stem_bottom'] and ax <= g['stem_half_width']:
        return True
    # Head: half width shrinks linearly from the base to the tip.
    if g['head_top'] <= y <= g['head_tip']:
        u = (y - g['head_top']) / (g['head_tip'] - g['head_top'])
        if ax <= g['head_half_width'] * (1.0 - u):
            return True
    # Base bar, with rounded ends.
    if g['bar'] and g['bar_top'] <= y <= g['bar_bottom']:
        w = g['bar_half_width']
        h = g['bar_bottom'] - g['bar_top']
        r = min(g['bar_radius'], h / 2.0, w)
        return in_rounded_rect(x + w, y - g['bar_top'], 2 * w, h, r)
    return False


def render(size):
    """Return a list of RGBA scanlines for a size x size image."""
    g = geometry_for(size)
    radius = TILE_RADIUS * size
    shield_h = g['shield_height'] * size
    shield_cx = size / 2.0
    shield_top = g['shield_centre_y'] * size - shield_h / 2.0

    step = 1.0 / SUPERSAMPLE
    offset = step / 2.0
    samples = SUPERSAMPLE * SUPERSAMPLE
    rows = []

    for py in range(size):
        row = bytearray()
        for px in range(size):
            # Accumulate premultiplied colour so partially covered edges blend correctly.
            acc_r = acc_g = acc_b = 0.0
            acc_a = 0.0
            for sy in range(SUPERSAMPLE):
                y = py + offset + sy * step
                for sx in range(SUPERSAMPLE):
                    x = px + offset + sx * step
                    if not in_rounded_rect(x, y, size, size, radius):
                        continue
                    # Shield-local coordinates, in units of the shield height.
                    ly = (y - shield_top) / shield_h
                    lx = (x - shield_cx) / shield_h
                    if in_shield(lx, ly, g) and not in_arrow(lx, ly, g):
                        r, gr, b = FG
                    else:
                        r, gr, b = tile_colour(y / size)
                    acc_r += r
                    acc_g += gr
                    acc_b += b
                    acc_a += 1.0

            if acc_a == 0.0:
                row += b'\x00\x00\x00\x00'
                continue
            alpha = acc_a / samples
            row += bytes((
                int(round(acc_r / acc_a)),
                int(round(acc_g / acc_a)),
                int(round(acc_b / acc_a)),
                int(round(alpha * 255)),
            ))
        rows.append(bytes(row))
    return rows


def png_chunk(kind, payload):
    return (struct.pack('>I', len(payload)) + kind + payload
            + struct.pack('>I', binascii.crc32(kind + payload) & 0xFFFFFFFF))


def png_bytes(width, height, rows):
    """Minimal RGBA PNG: IHDR, IDAT, IEND with CRC32s."""
    # Filter type 0 (None) in front of every scanline.
    raw = b''.join(b'\x00' + r for r in rows)
    ihdr = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    return (b'\x89PNG\r\n\x1a\n'
            + png_chunk(b'IHDR', ihdr)
            + png_chunk(b'IDAT', zlib.compress(raw, 9))
            + png_chunk(b'IEND', b''))


def ico_bytes(sizes):
    """PNG-compressed ICO (supported by Windows Vista and later)."""
    images = [(s, png_bytes(s, s, render(s))) for s in sizes]
    header = struct.pack('<HHH', 0, 1, len(images))
    offset = 6 + 16 * len(images)
    entries = b''
    for s, data in images:
        entries += struct.pack(
            '<BBBBHHII',
            0 if s >= 256 else s,   # 0 means 256 in the ICO directory
            0 if s >= 256 else s,
            0, 0, 1, 32, len(data), offset)
        offset += len(data)
    return header + entries + b''.join(d for _, d in images)


def preview_bytes(sizes, scale=7, gap=8):
    """Nearest-neighbour upscaled sheet on a checkerboard, for judging small sizes."""
    height = max(sizes) * scale
    width = sum(s * scale for s in sizes) + gap * (len(sizes) + 1)
    canvas = [[(60, 60, 70) if ((x // 8 + y // 8) % 2) else (82, 82, 94)
               for x in range(width)] for y in range(height)]

    x0 = gap
    for s in sizes:
        rows = render(s)
        for y in range(s * scale):
            for x in range(s * scale):
                i = (x // scale) * 4
                px = rows[y // scale][i:i + 4]
                a = px[3] / 255.0
                bg = canvas[y][x0 + x]
                canvas[y][x0 + x] = tuple(
                    int(round(c * a + bc * (1 - a))) for c, bc in zip(px[:3], bg))
        x0 += s * scale + gap

    rows = [b''.join(bytes(p) + b'\xff' for p in row) for row in canvas]
    return png_bytes(width, height, rows)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--png', default='SelfServicePatching-logo-256.png',
                    help='Company Portal / Intune app logo output path')
    ap.add_argument('--png-size', type=int, default=256,
                    help='logo edge length in pixels (Intune recommends 256)')
    ap.add_argument('--ico', default='../code/SelfServicePatching.ico',
                    help='shortcut icon output path; must sit beside the install script')
    ap.add_argument('--ico-sizes', default='16,20,24,32,48,64,128,256',
                    help='comma-separated sizes to embed in the .ico')
    ap.add_argument('--preview', metavar='PATH', nargs='?', const='preview.png',
                    help='also write an upscaled preview sheet of the small sizes')
    args = ap.parse_args()

    data = png_bytes(args.png_size, args.png_size, render(args.png_size))
    with open(args.png, 'wb') as fh:
        fh.write(data)
    print(f'{args.png}: {args.png_size}x{args.png_size}, {len(data):,} bytes')

    sizes = [int(s) for s in args.ico_sizes.split(',') if s.strip()]
    data = ico_bytes(sizes)
    with open(args.ico, 'wb') as fh:
        fh.write(data)
    print(f'{args.ico}: sizes {sizes}, {len(data):,} bytes')

    if args.preview:
        data = preview_bytes([16, 20, 24, 32, 48])
        with open(args.preview, 'wb') as fh:
            fh.write(data)
        print(f'{args.preview}: {len(data):,} bytes')


if __name__ == '__main__':
    main()
